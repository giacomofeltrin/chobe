baseurl_animeita = 'https://www.animesaturn.tv/'
baseurl_serie = 'https://streamingcommunity.cz/'